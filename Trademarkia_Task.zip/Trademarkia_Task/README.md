## Product Class Recommender

In this task I have implemented a simple ML pipeline using Logistic Regression with TfIDF 
vectorizer

### Data

The data is located in the data folder

### Model
 
The model is saved in the `model` folder with joblib module

### API

The API is implemented using FastAPI and hosted on Heroku

### Run

To run the application locally, use the following command:

```
uvicorn main:app --reload
```
```
curl -X 'POST' \
  'http://localhost:8000/predict?description=Fingerprint%20imagers' \
  -H 'accept: application/json' \
  -d ''
```

