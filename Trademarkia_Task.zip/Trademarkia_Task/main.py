from fastapi import FastAPI
import joblib

# Load the saved model
model = joblib.load('model/product_classifier.pkl')

# Create the FastAPI app
app = FastAPI()

@app.post('/predict')
def predict_class(description: str):
    # Make predictions using the loaded model
    prediction = model.predict([description])
    return {'class_id': prediction[0]}
