import json
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
import joblib

data_df = pd.read_json('./data/idmanual.json')

data_df["class_id"] = data_df["class_id"].astype(str)

print(f"Dataset size: {data_df.shape}")
print(f"Total unique classes: {data_df['class_id'].nunique()}")
print(f"Total unique classes: {data_df['class_id'].value_counts()}")
print(f"Total unique status: {data_df['status'].nunique()}")
print(f"Total unique status: {data_df['status'].unique()}")

X = data_df['description']
y = data_df['class_id']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a pipeline
pipeline = Pipeline([
    ('tfidf', TfidfVectorizer()),  # Convert text to TF-IDF features
    ('clf', LogisticRegression(solver="sag"))  # Use logistic regression as the classifier
])

# Train the pipeline
pipeline.fit(X_train, y_train)

# Evaluate the pipeline on the testing set
y_pred = pipeline.predict(X_test)
print(classification_report(y_test, y_pred))
joblib.dump(pipeline, 'model/product_classifier.pkl')

